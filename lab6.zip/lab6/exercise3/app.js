var express = require('express');
var app = express();
var mongoose = require('mongoose');

mongoose.connect('mongodb://test1:testpass1@ds161041.mlab.com:61041/dbtest');

var port = process.env.PORT || 3000;
app.listen(port);

var Schema = mongoose.Schema;

var userSchema = new Schema({ name: String, status: String });

var user = mongoose.model('User', userSchema);

var matt = user({ name: 'Matt', status: 'active' });

matt.save(function(err) {
    if (err) throw err;
    console.log('*** User Saved. ***');
});