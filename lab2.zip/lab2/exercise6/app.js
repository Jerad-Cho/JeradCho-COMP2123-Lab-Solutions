var events = require('events');
var eventEmitter = new events.EventEmitter();

var emit = function(){
    console.log('Event emitted');
}

var fn = function(){
    console.log('Function called to emit');
}

eventEmitter
.on('Emit', emit)
.on('Function', fn);

eventEmitter.emit('Emit')
eventEmitter.emit('Function');