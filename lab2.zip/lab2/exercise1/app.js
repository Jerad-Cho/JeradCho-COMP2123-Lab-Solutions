var ft = require('./sportsteam');
var comp = require('./comparer');
var calc = require('./calculator');

ft.teamname = 'Leafs';

num1 = 5;
num2 = 5;

ft.Cheer();
ft.Boo();

var result = (comp.AreNumberEqual(num1, num2)) ? calc.add(num1, num2) : calc.subtract(num1, num2);

console.log("Total: " + result);