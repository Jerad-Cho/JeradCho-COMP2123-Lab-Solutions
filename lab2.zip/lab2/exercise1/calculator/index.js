exports.add = function(num1, num2){
    total = num1 + num2
    console.log(num1 + " + " + num2 + " = " + total);
    return total;
}

exports.subtract = function(num1, num2){
    total = num1 - num2
    console.log(num1 + " - " + num2 + " = " + total);
    return total;
}