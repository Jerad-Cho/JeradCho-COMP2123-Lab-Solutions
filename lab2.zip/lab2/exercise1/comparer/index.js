exports.AreNumberEqual = function(num1, num2){
    console.log("Comparing two numbers: " + num1 + ", " + num2);
    if (num1 == num2){
        console.log("Numbers are equal");
    }
    else{
        console.log("Numbers are not equal");
    }
    return num1 == num2;
}
