var calc = require('./mod1');

calc.num1 = 3;
calc.num2 = 3;

calc.AreNumberEqual();
