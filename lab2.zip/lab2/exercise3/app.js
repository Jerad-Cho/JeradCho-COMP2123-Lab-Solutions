var events = require('events');
var eventEmitter = new events.EventEmitter();

var emit = function(){
    console.log("Alarm has been triggered.");
}

var fn = function(){
    console.log('call me.');
}

eventEmitter
.on('run', fn)
.on('stay', emit);

eventEmitter.emit('run');
eventEmitter.emit('stay');