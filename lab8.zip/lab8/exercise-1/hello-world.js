var greeter = function (firstName, lastName) {
    console.log("Hello " + firstName + " " + lastName);
};
greeter("John", "Smith");
