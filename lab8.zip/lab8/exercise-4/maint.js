"use strict";
exports.__esModule = true;
var cust_1 = require("./cust");
var customer = new cust_1.Customer("John", "Smith", "20");
customer.greeter();
customer.getAge();
