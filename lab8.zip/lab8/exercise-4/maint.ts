import { Customer } from './cust';

let customer = new Customer("John", "Smith", "20");
customer.greeter();
customer.getAge();