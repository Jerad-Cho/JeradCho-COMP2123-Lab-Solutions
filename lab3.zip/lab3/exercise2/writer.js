const fs = require('fs');
const file = fs.createWriteStream('./writer.txt');

var writeData = function(){

    for (let i = 0; i <= 10; i++){
        file.write('\nwrite line ' + i);
    }

    file.end();
}

module.exports = {
    writeData: writeData
}