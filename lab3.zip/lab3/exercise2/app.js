var wr = require('./writer.js');

wr.writeData();